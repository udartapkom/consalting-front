import React from "react";
import DATA from "../../constants/Data";
function Price(props){
    const { allPrice, getAllPrice } = props;
    React.useEffect(() => {
        getAllPrice()
    }, [])
    return (
        <section className="Price">
            <h2 className="Price__title">{DATA.PRICETITLE}</h2>
            {allPrice && allPrice.map((item, index) => (
                <div key={index} className="EditPrice__container">
                {item.titleShow && <h2 className="EditPrice__title">{item.title}</h2>}
                <div>{item.subtitle.map((el, index) => (
                    <div key={index}>
                        {el.textShow && <h3 className="EditPrice__subtitle">{el.text}</h3>}
                        <div>{el.service.map((cost, index) =>(
                            <div key={index} className="EditPrice__cost-container">
                                <p className="EditPrice__cost">{cost.name}</p>
                                <p className="EditPrice__cost">{cost.cost } &#8381;</p>
                            </div>
                        ))}</div>
                        </div>
                ))}</div>
                </div>
            ))}


           {/*  <h2 className="Price__title">{DATA.PRICETITLE}</h2>
            <ul className="Price__list">
                {tempData.map((item) => (
                    <li className="Price__list-item">
                        <h3 className="Price__subtitle">{item.title}</h3>
                        {item.subtitle.map((data) => (
                            <div className="Price__coast">
                                <p className="Price__text">{data.text}</p> 
                                <p className="Price__numbers">{data.price } &#8381; </p>
                                </div>
                        ))}
                    </li>
                ))}
            </ul> */}
        </section>
    )
}
export default Price;